using NUnit.Framework;


namespace List.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [TestCase(new int[3] { 1, 2, 3 }, 4, new int[4] { 1, 2, 3, 4 })]
        public void AddLastTest(int[] array, int value, int[] expected)
        {

            ArrayList arrayList = new ArrayList(array);
            arrayList.AddLast(value);
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);

        }
        [TestCase(new int[4] { 1, 2, 3, 4 }, 4, new int[5] { 4, 1, 2, 3, 4 })]
        public void AddFirstTest(int[] array, int value, int[] expected)
        {
            ArrayList arrayList = new ArrayList(array);
            arrayList.AddFirst(value);
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);

        }
        [TestCase(new int[3] { 1, 2, 3 }, new int[3] { 4, 5, 6 }, new int[6] { 4, 5, 6, 1, 2, 3 })]
        public void AddFirstTest(int[] array, int[] list, int[] newArray)
        {
            ArrayList arrayList = new ArrayList(array);
            ArrayList arrayList1 = new ArrayList(list);
            arrayList.AddFirst(arrayList1);
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(newArray, actual);
        }


        [TestCase(new int[] { 1, 2, 3 }, new int[] { 4, 5, 6 }, new int[] { 1, 2, 3, 4, 5, 6 })]
        [TestCase(new int[] { 1, 2, 3 }, new int[] { }, new int[] { 1, 2, 3 })]
        [TestCase(new int[] { 1, 2, 3 }, new int[] { 10 }, new int[] { 1, 2, 3, 10 })]
        [TestCase(new int[] { }, new int[] { 4, 5, 6 }, new int[] { 4, 5, 6 })]
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, new int[] { 4, 5, 6 }, new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 4, 5, 6 })]
        public void AddLastTest(int[] array, int[] list, int[] newArray)
        {
            //arrange
            ArrayList arrayList = new ArrayList(array);
            ArrayList arrayList1 = new ArrayList(list);

            //act
            arrayList.AddLast(arrayList1);
            int[] actual = arrayList.ToArray();

            //assert
            Assert.AreEqual(newArray, actual);
        }
        [TestCase(new int[3] { 1, 2, 3 }, 2, new int[2] { 4, 5 }, new int[5] { 1, 2, 4, 5, 3 })]
        public void AddAtTest(int[] array, int idx, int[] array1, int[] forExpected)
        {
            ArrayList arrayList = new ArrayList(array);
            ArrayList arrayList1 = new ArrayList(array1);
            ArrayList expected = new ArrayList(forExpected);

            arrayList.AddAt(idx, arrayList1);

            //int[] actual = arrayList.ToArray();

            Assert.AreEqual(expected, arrayList);
        }
        [TestCase(2, 5, new int[4] { 1, 2, 3, 4 }, new int[5] { 1, 2, 5, 3, 4 })]
        [TestCase(1, 4, new int[3] { 1, 2, 3 }, new int[4] { 1, 4, 2, 3 })]
        public void AddAtT(int idx, int val, int[] array, int[] expected)
        {
            ArrayList arrayList = new ArrayList(array);

            arrayList.AddAt(idx, val);
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);
        }
        
        [TestCase(new int[3] { 1, 2, 3 }, new int[2] {2, 3 })]
        public void RemoveFirstTest(int[] array, int[] expected)
        {
            ArrayList arrayList = new ArrayList(array);
            arrayList.RemoveFirst();
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);
        }
        [TestCase(new int[] {1,2,3}, new int[] { 1,2})]
        public void RemoveLastTest(int[]array, int []expected)
        {
            ArrayList arrayList = new ArrayList(array);
            arrayList.RemoveLast();
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);
        }
        [TestCase(new int[] {1,2,3},1, new int[] {1,3})]
        public void RemoveAtTest(int[]array,int idx, int[]expected)
        {
            ArrayList arrayList = new ArrayList(array);
            arrayList.RemoveAt(idx);
            int[] actual = arrayList.ToArray();
            Assert.AreEqual(expected, actual);
        }

    }
}