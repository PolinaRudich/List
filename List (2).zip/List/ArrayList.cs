﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace List
{
    public class ArrayList
    {

        private int[] _array;
        private const int _minLength = 10;
        public int Length { get; private set; }
        public ArrayList()
        {
            Length = 0;
            _array = new int[_minLength];
        }
        public ArrayList(int value)
        {
            Length = 1;
            _array = new int[_minLength];
            _array[0] = value;

        }
        public ArrayList(int[] array)
        {
            Length = array.Length;
            _array = new int[_minLength];
            for (int i = 0; i < array.Length; i++)
            {
                _array[i] = array[i];
            }
        }

        public int[] ToArray()
        {
            int[] array = new int[Length];
            for (int i = 0; i < Length; i++)
            {
                array[i] = _array[i];
            }
            return array;

        }
        public void AddLast(int value)
        {
            if (Length == _array.Length)
            {
                UpSize();
            }

            _array[Length] = value;
            Length++;
        }
        private void UpSize()
        {
            int newLength = _array.Length * 3 / 2;
            int[] tmpArray = new int[newLength];
            for (int i = 0; i < _array.Length; i++)
            {
                tmpArray[i] = _array[i];

            }

            _array = tmpArray;
        }


        public int this[int index]
        {
            get
            {
                return _array[index];
            }
            set
            {
                _array[index] = value;
            }
        }
        public int GetLength(int[] array)
        {
            return array.Length;
        }
        public void AddFirst(int value)
        {
            if (Length == _array.Length)
            {
                UpSize();
            }


            int[] tmpArray = new int[_array.Length];


            for (int i = 0; i < _array.Length - 1; i++)
            {
                tmpArray[i + 1] = _array[i];
            }
            tmpArray[0] = value;


            _array = tmpArray;



            Length++;
            //10
            //15
            //22
            //33



            // 11   15
            // 10   10

            //while(Length<=(_array.Length/2))
            //{
            //    DownSize();
            //}
        }
        private void DownSize()
        {
            int newLenght = _array.Length * 2 / 3;
            int[] tmpArray = new int[newLenght];
            for (int i = 0; i < newLenght; i++)
            {
                tmpArray[i] = _array[i];
            }
            _array = tmpArray;
        }
        // 24 
        // RemoveAtMuliple(5,17)
        // 7

        // 33
        // 10

        //public override bool Equals(object obj)
        //{
        //    ArrayList arrayList = (ArrayList)obj;

        //    if (Length != arrayList.Length && !_array.Equals(arrayList._array))
        //    {
        //        return false;
        //    }
        //    return true;

        //}
        public void AddAt(int idx, int val)
        {
            if (Length == _array.Length)
            {
                UpSize();
            }

            //int[] tmpArray = new int[Length];
            for (int i = Length - 1; i >= idx; i--)
            {
                _array[i + 1] = _array[i];
            }

            _array[idx] = val;
            Length++;
        }
        public void AddFirst(ArrayList list)
        {
            int newLength = _array.Length + list.Length;
            int[] tmpArray = new int[newLength];
            int[] arrayList = list.ToArray();
            for (int i = 0; i < arrayList.Length; i++)
            {
                tmpArray[i] = arrayList[i];
            }

            for (int i = 0; i < _array.Length; i++)
            {
                tmpArray[arrayList.Length + i] = _array[i];
            }
            _array = tmpArray;
            Length = newLength;
        }
        public void AddLast(ArrayList list)
        {
            //if (Length == _array.Length)
            //{
            //    UpSize();
            //}
            int newLength = Length + list.Length;
            int[] tmpArray = new int[newLength];
            for (int i = 0; i < Length; i++)
            {
                tmpArray[i] = _array[i];
            }


            for (int i = 0; i < list.Length; i++)
            {
                tmpArray[Length + i] = list._array[i];
            }
            _array = tmpArray;
            Length = newLength;

        }
        public void AddAt(int idx, ArrayList list)
        {
            // length 10 => 15
            //

            // idx 5  list.Length = 58

            //TODO: refactor upsize to any length

            if (Length == _array.Length)
            {
                UpSize();
            }

            //int[] tmpArray = new int[Length];
            int[] tmp1 = new int[idx];
            int[] tmp2 = new int[Length - idx];
            for (int i = 0; i < tmp1.Length; i++)
            {
                tmp1[i] = _array[i];
            }
            for (int i = 0; i < tmp2.Length; i++)
            {
                tmp2[i] = _array[i + idx];
            }

            //int newLength = Length + list.Length;
            int newLength = _array.Length + list.Length;
            Console.Write($"{_array.Length},{list.Length}");
            ArrayList tmpList1 = new ArrayList(tmp1);
            tmpList1.AddLast(list);
            ArrayList tmpList2 = new ArrayList(tmp2);
            tmpList1.AddLast(tmpList2);
            _array = tmpList1.ToArray();
            Length = newLength;
            //Console.WriteLine(Length);
            //Console.WriteLine(_array.Length);
            //Console.WriteLine(list.Length);
        }
        public void RemoveFirst()
        {
            int[] tmpArray = new int[_array.Length-1];
            for (int i =0; i <_array.Length-1; i++)
            {
                tmpArray[i] = _array[i+1];
            }
            Length--;
            _array = tmpArray;
          

        }
        public void RemoveLast()
        {
            int[] tmpArray = new int[_array.Length - 1];
            for (int i = 0; i < _array.Length - 1; i++)
            {
                tmpArray[i] = _array[i];
            }
            Length--;
            _array = tmpArray;
        }

        public override bool Equals(object obj)
        {
            return obj is ArrayList list &&
                  Enumerable.SequenceEqual(_array, list._array) &&
                   Length == list.Length;
        }
         public void RemoveAt(int idx)
        {
            //int[] tmpArray = new int[Length - 1];
          
            //for (int i = 0; i < Length; i++)
            //{
            //    if(i<idx)
            //    {
            //        tmpArray[i] = _array[i];
            //    }
            //    if(i>idx)
            //    {

            //        tmpArray[i-1] = _array[i];
                   
                    
            //    }
            //    if (i == idx)
            //    {
            //        continue;
            //    }
            //    _array = tmpArray;
            //    Length--;
            if((idx>=0)&&(idx<Length))
            {
                for (int i = idx; i < Length-1; i++)
                {
                    _array[i] = _array[i + 1];
                }
                Length--;
            }
            
            //Console.WriteLine(tmpArray.Length);
        }
        public void RemoveFirstMultiple(int n)
        {
           
        }
         public int GetFirst()
        {
            int n = 0;
            int[] array = new int[Length];
            for (int i = 0; i < Length; i++)
            {
                array[i] = _array[i];
                 n = array[0];
            }
            return n;
             
        }
        public int GetLast()
        {
            int n = 0;
            int[] array = new int[Length];
            for (int i = 0; i < Length; i++)
            {
                array[i] = _array[i];
                n = array[Length];
            }
            return n;

        }
        public void Sort()
        {

        }
    }
}
